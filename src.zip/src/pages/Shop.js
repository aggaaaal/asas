import React, { useState } from "react";
import { Link } from "react-router-dom";

const Shop = ({ addToCart }) => {
  const [category, setCategory] = useState("");
  const [priceRange, setPriceRange] = useState([]);

  const products = [
    { id: 1, name: "Product 1", price: 100, image: "https://via.placeholder.com/150", category: "Furniture" },
    { id: 2, name: "Product 2", price: 200, image: "https://via.placeholder.com/150", category: "Furniture" },
    { id: 3, name: "Product 3", price: 150, image: "https://via.placeholder.com/150", category: "Accessories" },
    { id: 4, name: "Product 4", price: 250, image: "https://via.placeholder.com/150", category: "Accessories" },
  ];

  const filteredProducts = products.filter((product) => {
    return (
      (category ? product.category === category : true) &&
      (priceRange.length
        ? product.price >= priceRange[0] && product.price <= priceRange[1]
        : true)
    );
  });

  return (
    <div className="bg-gray-100 min-h-screen">
      {/* Header Section */}
      <header className="bg-white shadow-md py-4 px-8 flex items-center justify-between">
        {/* Логотип */}
        <h1 className="text-2xl font-bold text-gray-800">Furniro</h1>

        {/* Центрированные ссылки */}
        <nav className="flex-1 flex justify-center space-x-8">
          <Link to="/" className="text-gray-600 hover:text-gray-800">
            Home
          </Link>
          <Link to="/shop" className="text-gray-600 hover:text-gray-800">
            Shop
          </Link>
          <Link to="/contact" className="text-gray-600 hover:text-gray-800">
            Contact
          </Link>
          <Link to="/cart" className="text-gray-600 hover:text-gray-800">
            Cart
          </Link>
        </nav>

        {/* Иконки справа */}
        <div className="flex space-x-6 items-center">
          <img
            src="https://cdn-icons-png.flaticon.com/128/3917/3917032.png"
            alt="Shop Icon"
            className="w-6 h-6 cursor-pointer"
          />
          <Link to="/cart">
            <img
              src="https://cdn-icons-png.flaticon.com/128/3916/3916598.png"
              alt="Cart Icon"
              className="w-6 h-6 cursor-pointer"
            />
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-gray-800">Shop</h1>

          {/* Filters */}
          <div className="flex space-x-4">
            <select
              onChange={(e) => setCategory(e.target.value)}
              className="p-2 border border-gray-300 rounded"
            >
              <option value="">Select Category</option>
              <option value="Furniture">Furniture</option>
              <option value="Accessories">Accessories</option>
            </select>

            <select
              onChange={(e) =>
                setPriceRange(e.target.value ? e.target.value.split(",").map(Number) : [])
              }
              className="p-2 border border-gray-300 rounded"
            >
              <option value="">Select Price Range</option>
              <option value="0,100">Up to $100</option>
              <option value="100,200">$100 - $200</option>
              <option value="200,500">$200 - $500</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              className="bg-white p-4 rounded-lg shadow-lg hover:shadow-xl"
            >
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-48 object-cover rounded-lg mb-4"
              />
              <h3 className="text-xl font-semibold text-gray-800">{product.name}</h3>
              <p className="text-lg text-gray-600">${product.price}</p>
              <div className="mt-4 flex justify-between items-center">
                <button
                  onClick={() => addToCart(product)}
                  className="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600"
                >
                  Add to Cart
                </button>
                <Link
                  to={`/product/${product.id}`}
                  className="text-yellow-500 hover:text-yellow-700"
                >
                  View Details
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Shop;
