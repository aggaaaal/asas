import React from "react";
import { Link } from 'react-router-dom';
import Header from '../components/Header';
const Home = () => {
  return (
    <div className="bg-gray-100 text-gray-800">
      {/* Header Section */}
      <header className="bg-gray-200 py-4 fixed w-full top-0 z-50 shadow-md">
        <div className="max-w-7xl mx-auto flex justify-between items-center px-4">
          {/* Логотип слева */}
          <div className="text-2xl font-bold text-gray-800">Furniro</div>

          {/* Ссылки по центру */}
          <nav className="flex space-x-8">
            <Link to="/" className="text-lg font-medium text-gray-700 hover:text-gray-900">
              Home
            </Link>
            <Link to="/shop" className="text-lg font-medium text-gray-700 hover:text-gray-900">
              Shop
            </Link>
            <Link to="/contact" className="text-lg font-medium text-gray-700 hover:text-gray-900">
              Contact
            </Link>
          </nav>

          {/* Иконки справа */}
          <div className="flex items-center space-x-6">
            <img
              src="https://cdn-icons-png.flaticon.com/128/3917/3917032.png"
              alt="Shop Icon"
              className="w-6 h-6"
            />
            <img
              src="https://cdn-icons-png.flaticon.com/128/3916/3916598.png"
              alt="Cart Icon"
              className="w-6 h-6"
            />
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <div
        className="relative bg-center bg-no-repeat pt-20"
        style={{
          backgroundImage:
            'url("https://i.pinimg.com/736x/9b/e6/60/9be660b722e9f8048ab0ba92371c6dd9.jpg")',
          backgroundSize: "cover",
          height: "100vh",
        }}
      >
        {/* Overlay */}
        <div className="absolute inset-0 bg-gray-900 opacity-40"></div>

        {/* Центрированный текст в сером квадрате */}
        <div className="absolute inset-0 flex flex-col justify-center items-center text-center text-white">
          <div className="bg-gray-800 p-8 rounded-lg shadow-xl max-w-md w-full ml-80"> {/* Добавлен отступ слева */}
            <h1 className="text-4xl font-bold mb-4">Discover Our New Collection</h1>
            <p className="text-lg mb-6">Find the perfect furniture for your home.</p>
            <Link to="/shop">
              <button className="bg-yellow-500 text-white px-6 py-3 rounded-full shadow-lg hover:bg-yellow-600">
                Shop Now
              </button>
            </Link>
          </div>
        </div>
      </div>

      {/* Browse The Range Section */}
      <div className="py-24 px-4 md:px-8 lg:px-16 xl:px-32 bg-white">
        <h2 className="text-4xl font-bold text-center mb-16">Browse The Range</h2>
        <div className="flex flex-col md:flex-row justify-center items-center gap-12 lg:gap-16 xl:gap-24">
          <div className="category text-center w-full md:w-1/3 max-w-md">
            <img
              src="https://i.pinimg.com/736x/c6/60/da/c660dacfa2c0217efb2a35423ac8464f.jpg"
              alt="Dining"
              className="w-full h-96 object-cover rounded-lg mb-6 shadow-lg"
            />
            <h3 className="text-2xl font-semibold">Dining</h3>
          </div>
          <div className="category text-center w-full md:w-1/3 max-w-md">
            <img
              src="https://i.pinimg.com/736x/8b/ea/9d/8bea9d7d01baed1ea7a0cb25ddb096a3.jpg"
              alt="Living"
              className="w-full h-96 object-cover rounded-lg mb-6 shadow-lg"
            />
            <h3 className="text-2xl font-semibold">Living</h3>
          </div>
          <div className="category text-center w-full md:w-1/3 max-w-md">
            <img
              src="https://i.pinimg.com/736x/7c/e1/46/7ce1467799f125762966b84879191148.jpg"
              alt="Bedroom"
              className="w-full h-96 object-cover rounded-lg mb-6 shadow-lg"
            />
            <h3 className="text-2xl font-semibold">Bedroom</h3>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-800 py-6 text-center text-white">
        <p>© 2024 Furniro. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default Home;
