import React from 'react';

const Contact = () => {
  return (
    <div>
      <h2>Свяжитесь с нами</h2>
      {/* Добавьте контактную форму или контактную информацию */}
    </div>
  );
};

export default Contact;